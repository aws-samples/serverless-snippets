/* 
Node.js code here.
*/

// ES6+ example
// import { createRequire } from 'module';
// const require = createRequire(import.meta.url);
import { RDSClient, ListTagsForResourceCommand } from "@aws-sdk/client-rds";
import { Signer } from "@aws-sdk/rds-signer";
import mysql from 'mysql2/promise';

const region = process.env.AWS_REGION;
const hostname = process.env.ProxyHostName;
const port = process.env.Port;
const username = process.env.DBUserName
const rds = new RDSClient({ region: region });
const signer = new Signer({
  /**
   * Required. The hostname of the database to connect to.
   */
  hostname: hostname,
  /**
   * Required. The port number the database is listening on.
   */
  port: port,
  /**
   * Required. The username to login as.
   */
  username: username,
  /**
   * Optional. The AWS credentials to sign requests with. Uses the default credential provider chain in not specified.
   */
  //credentials: fromNodeCredentialProvider(),
  /**
   * Optional. The region the database is located in. Uses the region inferred from the runtime if omitted.
   */
  region: region,
  /**
   * Optional. The SHA256 hasher constructor to sign the request.
   */
  //sha256: HashCtor,
});

async function createAuthToken() {

  const token = await signer.getAuthToken();
  return token;

}

async function dbOps() {

  //const username = process.env.RDS_USERNAME;
  
  // Get auth token
  const token = await createAuthToken();
  console.log(token)

  // Create connection
  //const mysql = require('mysql')
  const connection =  mysql.createConnection({
    host: process.env.RDS_ENDPOINT,
    user: username,
    password: token,
    database: process.env.DBName,
    ssl: true
  });

  try {
    // Connect to database
    await connection.connect();
  } catch (error) {
    console.error(error);
    return error;
  }

  return connection;

}

export const handler = async(event) => {
    try {
          // Get database connection
      const conn = await dbOps();
    
      // Execute query
      const [result] = await conn.execute('SELECT CURDATE() AS currentDate');
    
      // Return result
      return {
        statusCode: 200,
        body: JSON.stringify(result) 
      }
    }
    catch (e) {
        console.error(e);
        return 500;
    }
};
